$(document).ready(function () {

    $("#btnIniciarSesion").click(function () {
        if ($("#username").val().length < 1  && $("#password").val().length < 1) {
            alert("debe rellenar todos los campos")
        } else {      
            
            

                var xhr = new XMLHttpRequest();
                xhr.open("POST", "../Controlador/Controlador.php", true);

                xhr.setRequestHeader("Content-Type", "application/json");

                var datos={
                    username: $("#username").val(),
                    password: $("#password").val(),
                    opcion: "recuperar_usuario"
                };


                var datosJSON = JSON.stringify(datos);

                xhr.onload = function () {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var respuesta = xhr.responseText;
                       
                        if(respuesta == "1"){
                            window.location.href = "../Vista/index.php";
                        }else{
                            alert("Credenciales invalidas");
                        }
                    }else{
                        console.error("Hubo un error en la solicitud. Código de estado: " + xhr.status);
                    }
                }

                xhr.send(datosJSON);

                /*
                    $.ajax({
                        type: "POST",
                        url: "../Controlador/Controlador.php",
                        data: datos,
                        dataType: "json",
                            
                        success: function(response) {
                            console.log(response);
                            if (response==1) {
                                //$(location).attr('href', "../Vista/index.php")
                                window.location.href = "../Vista/index.php";
                            } else {
                                alert("Cedenciales invalidas");
                            }
                        }
                   })
*/
        }
    })


    function closemdl(usuario){
        $("#closemdl").trigger("click");

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "../Mail/Mailsend/mailsend.php", true);

        xhr.setRequestHeader("Content-Type", "application/json");

        var datos={
             username: usuario,
        };

        var datosJSON = JSON.stringify(datos);
        
        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                var respuesta = xhr.responseText;
                console.log(respuesta);
                alert(respuesta.message);
            }else{
                console.error("Hubo un error en la solicitud. Código de estado: " + xhr.status);
            }
        }

        xhr.send(datosJSON);




/*
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function (){
            if(this.readyState == 4 && this.status == 200){
                console.log(this.responseText);
                var response = JSON.parse(this.responseText);
                alert(response.message);
            }
        };

        xhttp.open("POST", "../Mail/Mailsend/mailsend.php?id="+usuario, true);
        xhttp.send();
*/
    }

    $("#getpass").click(function(){
        
        var user = $("#userN").val();
        
        setTimeout(closemdl(user), 1000);
        
    })

})