<?php

require_once "../Modelo/Modelo.php";

$enlace = new modelo();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = file_get_contents("php://input");

    $datos = json_decode($data);

    if ($datos !== null) {
        $OP = $datos->opcion;

        switch($OP){
            case "recuperar_usuario":
                $user = $datos->username;
                $pass = $datos->password;

                $response = $enlace->getUser($user, $pass);

                header('Content-Type: application/json');
                echo json_encode($response);
            break;
        }

    }else{
        http_response_code(400);
        echo json_encode(array("error" => "No se pudieron procesar los datos."));
    }
}else{
    http_response_code(405);
    echo json_encode(array("error" => "Método no permitido"));
}



/*
if (isset($_POST["opcion"])) {
    $op = $_POST["opcion"];
    $enlace = new modelo();

    switch ($op) {
        case 'recuperar_usuario':
            $resp=$enlace->getUser($_POST["username"], $_POST["password"]);
            echo json_encode($resp);
            break;
    }
}
*/
?>