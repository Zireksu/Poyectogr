<?php

    class modelo{

    public function getUser($user, $pass)
    {
        
        require_once '../Conexion/conexion.php';
        $sql =  "CALL Get_User_Data('".$user."', '".$pass."')";
        $statement = $db->prepare($sql);
        $statement->execute();


        while ($row= $statement->fetch(PDO::FETCH_ASSOC)) {
        
            $Check = $row['cont'];
    
        }

        if ($Check == 1) {
            return 1;
        }else {
            return null;
        }
    }


    public function getMail($user)
    {
        require_once 'config.php';
        global $db;

        $sql = "CALL get_email('".$user."')";
        $response = $db->prepare($sql);
        $response->execute();

        while($val = $response->fetch(PDO::FETCH_ASSOC)){
            $email = $val['mail'];
        }

        
        return $email;
    }

    public function changepass($user, $comb)
    {
        require_once 'config.php';
        global $db;

        $sql = "CALL change_pass('".$user."', '".$comb."')";
        $response = $db->prepare($sql);
        $response->execute();

        
        return 0;
    }

    public function get_pass($user)
    {
        require_once 'config.php';
        global $db;

        $sql = "CALL get_pass('".$user."')";
        $response = $db->prepare($sql);
        $response->execute();

        while($val = $response->fetch(PDO::FETCH_ASSOC)){
            $pass = $val['pass'];
        }

        
        return $pass;

    }

}
